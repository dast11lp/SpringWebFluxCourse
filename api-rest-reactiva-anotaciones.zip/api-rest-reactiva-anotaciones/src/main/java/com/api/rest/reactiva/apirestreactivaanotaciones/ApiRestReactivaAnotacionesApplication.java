package com.api.rest.reactiva.apirestreactivaanotaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestReactivaAnotacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestReactivaAnotacionesApplication.class, args);
	}

}
