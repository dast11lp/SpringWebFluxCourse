package com.api.rest.reactiva.apirestreactivaanotaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestReactivaAnotacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
